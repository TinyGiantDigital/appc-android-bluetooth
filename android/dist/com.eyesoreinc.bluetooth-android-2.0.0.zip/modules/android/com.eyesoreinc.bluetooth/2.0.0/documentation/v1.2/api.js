YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "BluetoothModule"
    ],
    "modules": [],
    "allModules": []
} };
});